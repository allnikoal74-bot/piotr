# ALLNIKO — instrukcja wdrożenia

To jest prawdziwy, gotowy do wdrożenia szkielet platformy: logowanie, panel klienta,
baza danych i pipeline zamówień "klient → agent AI → wynik e-mailem".

## Jak działa pipeline zamówień (to, o co prosiłeś)

```
Klient wypełnia formularz (/order)
        │
        ▼
POST /api/orders  ──── (albo n8n woła ten sam endpoint jako webhook)
        │
        ├─ 1. Zapis zamówienia w Supabase (status: w_toku)
        ├─ 2. Uruchomienie właściwego agenta AI (Claude API)
        ├─ 3. Zapis wyniku (status: gotowe)
        ├─ 4. Wysyłka e-maila do klienta z wynikiem (status: wyslane)
        └─ 5. Każdy krok loguje się w tabeli agent_logs
```

n8n **nie musi** hostować logiki agenta — może być cienką warstwą, która np.
odbiera formularz z Twojej starej strony i przekazuje dane do `/api/orders`,
albo odwrotnie: nasłuchuje na zmiany w tabeli `orders` i wysyła powiadomienie
na Slacka/WhatsApp. Oba kierunki są możliwe przez zwykłe wywołanie HTTP.

## Krok 1 — Supabase (baza danych + logowanie)

1. Załóż darmowe konto na [supabase.com](https://supabase.com) i nowy projekt.
2. Wejdź w **SQL Editor** i wklej całą zawartość pliku `supabase/schema.sql`, kliknij Run.
3. W **Project Settings → API** skopiuj: `Project URL`, `anon public key`, `service_role key`.

## Krok 2 — zmienne środowiskowe

1. Skopiuj `.env.local.example` jako `.env.local`.
2. Uzupełnij dane z Supabase (krok 1).
3. Dodaj `ANTHROPIC_API_KEY` z [console.anthropic.com](https://console.anthropic.com/settings/keys).
4. (Opcjonalnie) dodaj `RESEND_API_KEY` z [resend.com](https://resend.com) — bez tego
   agent nadal będzie działał i zapisywał wyniki w bazie, tylko nie wyśle e-maila.

## Krok 3 — uruchomienie lokalnie

```bash
npm install
npm run dev
```

Otwórz `http://localhost:3000/order` — to publiczny formularz zamówienia.
Otwórz `http://localhost:3000/login` — logowanie do panelu klienta.

## Krok 4 — wdrożenie na Vercel

1. Wrzuć ten katalog do repozytorium GitHub.
2. Wejdź na [vercel.com](https://vercel.com) → New Project → wskaż repo.
3. W **Environment Variables** wklej dokładnie te same zmienne co w `.env.local`.
4. Deploy. Dostaniesz działający adres `https://twoj-projekt.vercel.app`.
5. Podepnij własną domenę (np. `allniko.pl`) w ustawieniach projektu Vercel.

## Krok 5 — podłączenie n8n

W n8n dodaj node **HTTP Request** wywołujący:

```
POST https://twoja-domena.pl/api/orders
Content-Type: application/json

{
  "client_email": "{{ $json.email }}",
  "client_name": "{{ $json.name }}",
  "agent_type": "grafika",
  "description": "{{ $json.opis }}",
  "webhook_secret": "TEN_SAM_SEKRET_CO_W_ENV"
}
```

`agent_type` może być jednym z: `sales`, `wnetrza`, `nadruki`, `grafika`, `prawnik`, `ksiegowa`, `serwis`.

## Krok 6 — płatności BLIK / Przelewy24 (Polska)

Kod integracji jest już gotowy w projekcie (`/api/przelewy24/register` i `/api/przelewy24/webhook`). Żeby zaczął działać:

1. Załóż konto na [przelewy24.pl](https://www.przelewy24.pl) (wymaga NIP-u firmy, weryfikacja zwykle 1-2 dni robocze).
2. Po zatwierdzeniu, w panelu P24 → **Ustawienia → Twoje dane** znajdziesz: `merchantId`, `posId`, `apiKey`, `crcKey`.
3. Wklej je do zmiennych środowiskowych w Vercel: `P24_MERCHANT_ID`, `P24_POS_ID`, `P24_API_KEY`, `P24_CRC_KEY`.
4. Zacznij z `P24_SANDBOX=true` — P24 udostępnia środowisko testowe z fikcyjnymi płatnościami, żebyś mógł sprawdzić czy wszystko działa, zanim przyjmiesz prawdziwe pieniądze. Gdy przetestujesz, zmień na `P24_SANDBOX=false`.

## Krok 6b — płatności międzynarodowe (Stripe, cały świat)

To samo zastrzeżenie co przy Przelewy24: **nie mogę założyć Ci konta Stripe** — to wymaga Twoich danych firmowych. Ale kod integracji jest już gotowy w projekcie:

1. Załóż konto na [stripe.com](https://stripe.com) (dostępne globalnie, weryfikacja zwykle szybsza niż w polskich operatorach).
2. W Dashboard Stripe → **Developers → API keys** skopiuj `Secret key` → wklej jako `STRIPE_SECRET_KEY` w Vercel.
3. W **Developers → Webhooks** dodaj endpoint: `https://twoja-domena.pl/api/stripe-webhook`, nasłuchujący na zdarzenia `checkout.session.completed` i `invoice.payment_failed`. Skopiuj wygenerowany `Signing secret` → wklej jako `STRIPE_WEBHOOK_SECRET`.
4. Dodaj `NEXT_PUBLIC_SITE_URL` (adres Twojej wdrożonej strony) w Vercel.
5. Zacznij od **trybu testowego** (klucze zaczynające się od `sk_test_`) — dopiero jak przetestujesz, że wszystko działa, przełącz na klucze produkcyjne (`sk_live_`).

Platforma jest teraz gotowa na klientów z Polski (Przelewy24/BLIK — po Twoim wdrożeniu) i z całego świata (Stripe).

## Krok 7 — Asystent Telefoniczny AI (odbiera Twój telefon)

Kod jest gotowy (`/api/voice/incoming`, `/api/voice/respond`, `/api/voice/status`). Do uruchomienia:

1. Załóż konto na [twilio.com](https://twilio.com) i kup numer telefonu obsługujący Polskę (albo przekieruj swój obecny numer na numer Twilio — Twilio ma na to instrukcje).
2. W konsoli Twilio → **Phone Numbers** → wybierz swój numer → sekcja **Voice Configuration**:
   - "A call comes in" → Webhook → `https://twoja-domena.pl/api/voice/incoming`
   - "Call status changes" → Webhook → `https://twoja-domena.pl/api/voice/status`
3. Zadzwoń na testowy numer i sprawdź, czy asystent odpowiada.

**Ważne:** asystent zawsze mówi dzwoniącemu na starcie, że rozmawia z AI — to wymóg prawny w wielu krajach (w tym w Polsce), nie usuwaj tego zdania z kodu. Asystent nie podejmuje decyzji o cenach/rabatach przez telefon — zawsze zbiera dane kontaktowe i przekazuje sprawę Tobie e-mailem po zakończeniu rozmowy.

## Krok 8 — Monitoring AI (kontrola 24/7)

Kod i konfiguracja są już gotowe (`vercel.json` + `/api/health-check`). Vercel **automatycznie** wywołuje ten endpoint co 15 minut, bez żadnej dodatkowej instalacji — wystarczy że:

1. Dodasz `CRON_SECRET` do zmiennych środowiskowych w Vercel (dowolny losowy ciąg znaków).
2. Po wdrożeniu, Vercel sam ustawia nagłówek autoryzacji przy wywołaniach crona — nic więcej nie musisz robić.

Co się dzieje: co 15 minut system sam sprawdza, czy baza danych i kluczowe integracje działają, zapisuje wynik w panelu "Kondycja systemu", a jeśli coś jest nie tak — **dostajesz e-mail z alertem od razu**, zamiast dowiadywać się o awarii od klienta. Gdy wszystko działa poprawnie, nie dostajesz żadnego e-maila — tylko cichy wpis w logu.

**Uwaga:** Cron Jobs w Vercel na darmowym planie mają ograniczenia częstotliwości (sprawdź aktualne limity w dokumentacji Vercel) — jeśli `*/15 * * * *` nie zadziała na Twoim planie, zmień w `vercel.json` na rzadszy interwał, np. co godzinę: `"0 * * * *"`.

## Co dalej

Ten szkielet ma: logowanie, bazę, pipeline zamówień z agentami AI, wysyłkę e-mail.
Brakuje: prawdziwej strony głównej (styl z Twojej grafiki), panelu admina, płatności.
Powiedz, co budujemy jako kolejny krok.
