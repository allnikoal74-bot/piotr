-- ALLNIKO — schemat bazy danych Supabase (Postgres)
-- Wklej to w Supabase: Dashboard → SQL Editor → New query → Run

-- Profile klientów panelu (rozszerza wbudowaną tabelę auth.users Supabase)
create table if not exists profiles (
  id uuid references auth.users on delete cascade primary key,
  company_name text,
  created_at timestamptz default now()
);

-- Leady (Sales AI)
create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users on delete cascade,  -- null = lead z publicznego zamówienia, jeszcze nieprzypisany
  name text not null,
  company text,
  value numeric default 0,
  stage text default 'Nowy',
  created_at timestamptz default now()
);

-- Szkice faktur (Księgowa AI)
create table if not exists invoices (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users on delete cascade not null,
  client_name text not null,
  item text not null,
  net numeric not null,
  vat_rate numeric not null default 23,
  gross numeric not null,
  status text default 'Szkic',
  created_at timestamptz default now()
);

-- Zamówienia wpadające z formularza / n8n / webhooka
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users on delete set null,
  client_email text not null,
  client_name text,
  agent_type text not null,        -- np. 'grafika', 'prawnik', 'ksiegowa', 'web'
  payload jsonb not null,          -- treść zamówienia (opis, dane wejściowe)
  status text default 'nowe',      -- nowe -> w_toku -> gotowe -> wyslane -> blad
  result text,                     -- odpowiedź agenta AI (albo link do demo strony)
  demo_url text,                   -- publiczny link do wygenerowanej strony (Kreator Stron AI)
  created_at timestamptz default now(),
  completed_at timestamptz
);

-- WAŻNE: Kreator Stron AI publikuje wygenerowane strony jako pliki HTML.
-- Musisz ręcznie utworzyć bucket Storage w Supabase:
-- Dashboard -> Storage -> New bucket -> nazwa: "demos" -> Public bucket: TAK

-- Log każdego uruchomienia agenta — do panelu "Kondycja systemu"
create table if not exists agent_logs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders on delete cascade,
  agent_type text not null,
  event_type text not null,        -- 'start' | 'success' | 'error' | 'email_sent'
  detail text,
  created_at timestamptz default now()
);

-- Wiadomości negocjacyjne przygotowane przez Sales AI — czekają na Twoje
-- zatwierdzenie zanim pójdą do klienta. Agent NIGDY nie wysyła ich sam.
create table if not exists pending_messages (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users on delete cascade,
  lead_id uuid references leads on delete set null,
  client_email text not null,
  client_message text not null,     -- co napisał klient (np. prośba o rabat)
  draft_reply text not null,        -- gotowa odpowiedź agenta
  proposed_discount numeric,        -- proponowany rabat w % (jeśli dotyczy)
  max_discount_allowed numeric default 15,
  status text default 'oczekuje',   -- oczekuje -> zatwierdzone -> wyslane -> odrzucone
  created_at timestamptz default now(),
  approved_at timestamptz
);

alter table pending_messages enable row level security;

create policy "Użytkownik zarządza własnymi wiadomościami do zatwierdzenia" on pending_messages
  for all using (auth.uid() = owner_id);

-- Odwiedziny strony głównej / formularza zamówienia — do powiadomień
-- "ktoś wszedł na stronę" i podstawowej analityki bez zewnętrznych narzędzi.
create table if not exists site_visits (
  id uuid primary key default gen_random_uuid(),
  page text,
  referrer text,
  user_agent text,
  created_at timestamptz default now()
);
alter table site_visits enable row level security;

-- Rozmowy telefoniczne odebrane przez Asystenta Telefonicznego AI.
create table if not exists phone_calls (
  id uuid primary key default gen_random_uuid(),
  call_sid text unique not null,
  from_number text,
  transcript jsonb default '[]'::jsonb,   -- [{role:"caller"|"assistant", text:"..."}]
  status text default 'w_toku',            -- w_toku -> zakonczone
  created_at timestamptz default now(),
  ended_at timestamptz
);
alter table phone_calls enable row level security;
-- Brak polityk dla zwykłych użytkowników — zapis wyłącznie przez API
-- route z kluczem service role (webhooki Twilio).
-- Brak polityk select/insert dla zwykłych użytkowników — zapis odbywa się
-- wyłącznie przez API route z kluczem service role (patrz /api/track-visit).

alter table profiles enable row level security;
alter table leads enable row level security;
alter table invoices enable row level security;
alter table orders enable row level security;
alter table agent_logs enable row level security;

create policy "Użytkownik widzi własny profil" on profiles
  for select using (auth.uid() = id);

create policy "Użytkownik zarządza własnymi leadami" on leads
  for all using (auth.uid() = owner_id);

create policy "Użytkownik zarządza własnymi fakturami" on invoices
  for all using (auth.uid() = owner_id);

create policy "Użytkownik widzi własne zamówienia" on orders
  for select using (auth.uid() = owner_id);

-- Uwaga: wstawianie zamówień (insert) z formularza/n8n odbywa się przez
-- API route na serwerze (service role key), więc nie potrzebuje policy insert
-- dla zwykłych użytkowników — patrz app/api/orders/route.js
