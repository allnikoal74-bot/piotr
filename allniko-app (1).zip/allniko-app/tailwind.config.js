/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx,ts,tsx}",
    "./components/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: "#070B12",
        raised: "#0D1420",
        line: "#1B2636",
        ink: "#E7EEF7",
        inkdim: "#90A0B5",
        cyan: "#38D6F0",
        blue: "#4C7CF0",
        amber: "#FFB238",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["Inter", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
