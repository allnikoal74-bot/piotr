"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabaseClient";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleLogin(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError("Nieprawidłowy e-mail lub hasło.");
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <form onSubmit={handleLogin} className="w-full max-w-sm bg-raised border border-line rounded-2xl p-8 flex flex-col gap-4">
        <h1 className="font-display text-xl font-bold">Zaloguj się do ALLNIKO</h1>
        <input
          required type="email" placeholder="E-mail"
          className="bg-bg border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan"
          value={email} onChange={(e) => setEmail(e.target.value)}
        />
        <input
          required type="password" placeholder="Hasło"
          className="bg-bg border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan"
          value={password} onChange={(e) => setPassword(e.target.value)}
        />
        {error && <div className="text-amber text-sm">{error}</div>}
        <button type="submit" disabled={loading} className="bg-cyan text-bg font-bold rounded-lg py-3 text-sm disabled:opacity-60">
          {loading ? "Loguję…" : "Zaloguj się"}
        </button>
        <p className="text-inkdim text-sm text-center">
          Nie masz konta? <Link href="/register" className="text-cyan">Zarejestruj się</Link>
        </p>
      </form>
    </div>
  );
}
