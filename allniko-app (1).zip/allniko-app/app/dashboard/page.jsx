import { redirect } from "next/navigation";
import { createServerSupabaseClient } from "@/lib/supabaseServer";
import LogoutButton from "./LogoutButton";
import Link from "next/link";

export default async function DashboardPage() {
  const supabase = createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const { data: orders } = await supabase
    .from("orders")
    .select("*")
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false })
    .limit(20);

  return (
    <div className="min-h-screen p-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-2xl font-bold">Panel klienta</h1>
          <p className="text-inkdim text-sm">{user.email}</p>
        </div>
        <LogoutButton />
      </div>

      <div className="flex gap-3 mb-8 flex-wrap">
        <Link href="/dashboard/chat" className="bg-cyan text-bg font-bold px-4 py-2 rounded-lg text-sm">Czat z agentami</Link>
        <Link href="/dashboard/inbox" className="border border-line px-4 py-2 rounded-lg text-sm">Skrzynka wiadomości</Link>
        <Link href="/dashboard/reports" className="border border-line px-4 py-2 rounded-lg text-sm">Relacje z klientami</Link>
      </div>

      <h2 className="font-display font-semibold text-sm mb-3 text-inkdim uppercase tracking-wide">Ostatnie zamówienia</h2>
      <div className="flex flex-col gap-3">
        {(!orders || orders.length === 0) && (
          <div className="text-inkdim text-sm bg-raised border border-line rounded-xl p-4">
            Brak zamówień powiązanych z tym kontem jeszcze.
          </div>
        )}
        {orders?.map((o) => (
          <div key={o.id} className="bg-raised border border-line rounded-xl p-4">
            <div className="flex justify-between items-center text-sm">
              <span className="font-semibold">{o.agent_type}</span>
              <span className="text-xs font-mono text-inkdim">{o.status}</span>
            </div>
            <p className="text-inkdim text-xs mt-2 line-clamp-2">{o.payload?.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
