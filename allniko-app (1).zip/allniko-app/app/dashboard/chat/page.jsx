"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";

const AGENTS = [
  { value: "sales", label: "Sales AI" },
  { value: "marketing", label: "Marketing AI" },
  { value: "web", label: "Kreator Stron AI" },
  { value: "magazyn", label: "Magazyn AI" },
  { value: "nadruki", label: "Nadruki AI" },
  { value: "wnetrza", label: "Wnętrza AI" },
  { value: "grafika", label: "Grafika AI" },
  { value: "prawnik", label: "Prawnik AI" },
  { value: "ksiegowa", label: "Księgowa AI" },
  { value: "serwis", label: "Serwis AI" },
];

export default function ChatPage() {
  const [agent, setAgent] = useState("sales");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages, sending]);

  async function send() {
    const text = input.trim();
    if (!text || sending) return;
    setMessages((m) => [...m, { role: "user", text }]);
    setInput("");
    setSending(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agent_type: agent, message: text }),
      });
      const data = await res.json();
      setMessages((m) => [...m, { role: "assistant", text: data.reply || data.error || "Błąd odpowiedzi." }]);
    } catch {
      setMessages((m) => [...m, { role: "assistant", text: "Wystąpił błąd połączenia." }]);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col max-w-2xl mx-auto p-6">
      <div className="flex items-center justify-between mb-4">
        <Link href="/dashboard" className="text-inkdim text-sm">← Panel</Link>
        <select
          value={agent}
          onChange={(e) => { setAgent(e.target.value); setMessages([]); }}
          className="bg-raised border border-line rounded-lg px-3 py-2 text-sm"
        >
          {AGENTS.map((a) => <option key={a.value} value={a.value}>{a.label}</option>)}
        </select>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto flex flex-col gap-3 py-4">
        {messages.length === 0 && (
          <div className="text-inkdim text-sm text-center mt-10">Napisz do {AGENTS.find((a) => a.value === agent)?.label}, żeby zacząć.</div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[75%] rounded-xl px-4 py-2 text-sm whitespace-pre-wrap ${m.role === "user" ? "bg-cyan text-bg" : "bg-raised border border-line text-ink"}`}>
              {m.text}
            </div>
          </div>
        ))}
        {sending && <div className="text-inkdim text-xs">Agent pisze…</div>}
      </div>

      <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2 pt-3 border-t border-line">
        <input
          className="flex-1 bg-raised border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan"
          placeholder="Napisz wiadomość…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button type="submit" disabled={sending} className="bg-cyan text-bg font-bold px-5 rounded-lg text-sm disabled:opacity-60">Wyślij</button>
      </form>
    </div>
  );
}
