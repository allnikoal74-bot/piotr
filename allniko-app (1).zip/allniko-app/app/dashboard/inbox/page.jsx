import { redirect } from "next/navigation";
import { createServerSupabaseClient } from "@/lib/supabaseServer";
import Link from "next/link";
import InboxActions from "./InboxActions";

export default async function InboxPage() {
  const supabase = createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: pending } = await supabase
    .from("pending_messages")
    .select("*")
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false });

  return (
    <div className="min-h-screen max-w-2xl mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold">Skrzynka wiadomości</h1>
          <p className="text-inkdim text-sm">Odpowiedzi agentów czekające na Twoje zatwierdzenie</p>
        </div>
        <Link href="/dashboard" className="text-inkdim text-sm">← Panel</Link>
      </div>

      <div className="flex flex-col gap-4">
        {(!pending || pending.length === 0) && (
          <div className="text-inkdim text-sm bg-raised border border-line rounded-xl p-4">
            Brak wiadomości oczekujących. Nowe pojawią się tu, gdy agent przygotuje odpowiedź dla klienta (np. z propozycją rabatu).
          </div>
        )}
        {pending?.map((m) => (
          <div key={m.id} className="bg-raised border border-line rounded-xl p-5">
            <div className="flex justify-between text-xs text-inkdim font-mono mb-3">
              <span>{m.client_email}</span>
              <span>{m.status}</span>
            </div>
            <div className="text-xs text-inkdim mb-1">Klient napisał:</div>
            <div className="text-sm bg-bg border border-line rounded-lg p-3 mb-3">{m.client_message}</div>
            <div className="text-xs text-inkdim mb-1">Proponowana odpowiedź {m.proposed_discount > 0 ? `(rabat ${m.proposed_discount}%)` : ""}:</div>
            <div className="text-sm bg-bg border border-cyan rounded-lg p-3 mb-3 whitespace-pre-wrap">{m.draft_reply}</div>
            {m.status === "oczekuje" && <InboxActions id={m.id} />}
          </div>
        ))}
      </div>
    </div>
  );
}
