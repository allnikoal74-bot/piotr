"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function InboxActions({ id }) {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function act(action) {
    setLoading(true);
    await fetch(`/api/pending-messages/${id}/${action}`, { method: "POST" });
    setLoading(false);
    router.refresh();
  }

  return (
    <div className="flex gap-2">
      <button
        onClick={() => act("approve")}
        disabled={loading}
        className="bg-cyan text-bg font-bold text-sm px-4 py-2 rounded-lg disabled:opacity-60"
      >
        Zatwierdź i wyślij
      </button>
      <button
        onClick={() => act("reject")}
        disabled={loading}
        className="border border-line text-inkdim text-sm px-4 py-2 rounded-lg disabled:opacity-60"
      >
        Odrzuć
      </button>
    </div>
  );
}
