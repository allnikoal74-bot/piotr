"use client";

import { useState } from "react";
import Link from "next/link";

export default function ReportsPage() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle"); // idle | loading | done | error
  const [report, setReport] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  async function generate(e) {
    e.preventDefault();
    setStatus("loading");
    setErrorMsg("");
    try {
      const res = await fetch("/api/client-report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ client_email: email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Błąd");
      setReport(data.report);
      setStatus("done");
    } catch (err) {
      setErrorMsg(err.message);
      setStatus("error");
    }
  }

  return (
    <div className="min-h-screen max-w-2xl mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold">Relacje z klientami</h1>
          <p className="text-inkdim text-sm">Agent AI podsumowuje przebieg współpracy na podstawie realnych danych z systemu.</p>
        </div>
        <Link href="/dashboard" className="text-inkdim text-sm">← Panel</Link>
      </div>

      <form onSubmit={generate} className="flex gap-2 mb-8">
        <input
          required type="email" placeholder="E-mail klienta"
          className="flex-1 bg-raised border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan"
          value={email} onChange={(e) => setEmail(e.target.value)}
        />
        <button type="submit" disabled={status === "loading"} className="bg-cyan text-bg font-bold px-5 rounded-lg text-sm disabled:opacity-60">
          {status === "loading" ? "Analizuję…" : "Generuj raport"}
        </button>
      </form>

      {status === "error" && (
        <div className="text-amber text-sm bg-raised border border-line rounded-xl p-4">{errorMsg}</div>
      )}

      {status === "done" && (
        <div className="bg-raised border border-cyan rounded-xl p-5">
          <div className="text-xs text-inkdim font-mono mb-3 uppercase tracking-wide">Relacja — {email}</div>
          <div className="text-sm whitespace-pre-wrap leading-relaxed">{report}</div>
        </div>
      )}

      {status === "idle" && (
        <div className="text-inkdim text-sm bg-raised border border-line rounded-xl p-4">
          Wpisz e-mail klienta, żeby zobaczyć podsumowanie jego historii z agentami ALLNIKO — zamówienia, wiadomości, etap współpracy.
        </div>
      )}
    </div>
  );
}
