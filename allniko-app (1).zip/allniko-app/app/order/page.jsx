"use client";

import { useState } from "react";

const AGENT_OPTIONS = {
  pl: [
    { value: "web", label: "Kreator Stron AI — gotowa strona demo" },
    { value: "grafika", label: "Grafika AI — logo, key visual" },
    { value: "nadruki", label: "Nadruki AI — grafika na koszulki" },
    { value: "wnetrza", label: "Wnętrza AI — projekt wnętrza" },
    { value: "prawnik", label: "Prawnik AI — analiza umowy" },
    { value: "ksiegowa", label: "Księgowa AI — szkic faktury" },
    { value: "serwis", label: "Serwis AI — zgłoszenie techniczne" },
  ],
  en: [
    { value: "web", label: "Website Creator AI — ready demo site" },
    { value: "grafika", label: "Graphics AI — logo, key visual" },
    { value: "nadruki", label: "Print Design AI — t-shirt graphics" },
    { value: "wnetrza", label: "Interior AI — room design" },
    { value: "prawnik", label: "Legal AI — contract review" },
    { value: "ksiegowa", label: "Accounting AI — invoice draft" },
    { value: "serwis", label: "Support AI — technical request" },
  ],
};

const LABELS = {
  pl: { title: "Złóż zamówienie", subtitle: "Wypełnij formularz — odpowiedni agent AI zajmie się resztą i odeśle wynik na e-mail.", email: "Twój e-mail", name: "Imię i nazwisko (opcjonalnie)", desc: "Opisz czego potrzebujesz…", submit: "Wyślij zamówienie", sending: "Agent pracuje…", done: "Gotowe — sprawdź skrzynkę" },
  en: { title: "Place an order", subtitle: "Fill in the form — the right AI agent will handle it and send you the result by email.", email: "Your email", name: "Full name (optional)", desc: "Describe what you need…", submit: "Send order", sending: "Agent is working…", done: "Done — check your inbox" },
};

export default function OrderPage() {
  const [lang, setLang] = useState("pl");
  const t = LABELS[lang];
  const [form, setForm] = useState({ client_email: "", client_name: "", agent_type: "grafika", description: "" });
  const [status, setStatus] = useState("idle"); // idle | sending | done | error
  const [resultText, setResultText] = useState("");

  async function submit(e) {
    e.preventDefault();
    setStatus("sending");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, language: lang }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Nieznany błąd");
      setResultText(data.result);
      setStatus("done");
    } catch (err) {
      setStatus("error");
    }
  }

  return (
    <div className="min-h-screen bg-bg text-ink flex items-center justify-center p-6">
      <div className="w-full max-w-lg bg-raised border border-line rounded-2xl p-8">
        <div className="flex justify-between items-start mb-1">
          <h1 className="font-display text-2xl font-bold">{t.title}</h1>
          <div className="flex gap-1 text-xs">
            <button onClick={() => setLang("pl")} className={`px-2 py-1 rounded ${lang === "pl" ? "bg-cyan text-bg" : "text-inkdim"}`}>PL</button>
            <button onClick={() => setLang("en")} className={`px-2 py-1 rounded ${lang === "en" ? "bg-cyan text-bg" : "text-inkdim"}`}>EN</button>
          </div>
        </div>
        <p className="text-inkdim text-sm mb-6">{t.subtitle}</p>

        {status === "done" ? (
          <div>
            <div className="text-cyan font-semibold mb-2">{t.done} {form.client_email}</div>
            {resultText?.includes("http") ? (
              <a href={resultText.match(/https?:\/\/\S+/)?.[0]} target="_blank" rel="noreferrer" className="block bg-bg border border-cyan rounded-lg p-4 text-sm text-cyan break-all">
                {resultText.match(/https?:\/\/\S+/)?.[0] || resultText}
              </a>
            ) : (
              <div className="bg-bg border border-line rounded-lg p-4 text-sm whitespace-pre-wrap">{resultText}</div>
            )}
          </div>
        ) : (
          <form onSubmit={submit} className="flex flex-col gap-4">
            <input
              required type="email" placeholder={t.email}
              className="bg-bg border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan"
              value={form.client_email} onChange={(e) => setForm({ ...form, client_email: e.target.value })}
            />
            <input
              placeholder={t.name}
              className="bg-bg border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan"
              value={form.client_name} onChange={(e) => setForm({ ...form, client_name: e.target.value })}
            />
            <select
              className="bg-bg border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan"
              value={form.agent_type} onChange={(e) => setForm({ ...form, agent_type: e.target.value })}
            >
              {AGENT_OPTIONS[lang].map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <textarea
              required rows={4} placeholder={t.desc}
              className="bg-bg border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan resize-none"
              value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
            <button
              type="submit" disabled={status === "sending"}
              className="bg-cyan text-bg font-bold rounded-lg py-3 text-sm disabled:opacity-60"
            >
              {status === "sending" ? t.sending : t.submit}
            </button>
            {status === "error" && <div className="text-amber text-sm">{lang === "pl" ? "Coś poszło nie tak, spróbuj ponownie." : "Something went wrong, please try again."}</div>}
          </form>
        )}
      </div>
    </div>
  );
}
