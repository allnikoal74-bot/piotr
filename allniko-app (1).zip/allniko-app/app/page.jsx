import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-6 p-6 text-center">
      <h1 className="font-display text-3xl font-bold">ALLNIKO</h1>
      <p className="text-inkdim max-w-sm">AI dla Twojego biznesu — panel klienta i agenci AI.</p>
      <div className="flex gap-3">
        <Link href="/login" className="bg-cyan text-bg font-bold px-6 py-3 rounded-lg text-sm">Zaloguj się</Link>
        <Link href="/order" className="border border-line px-6 py-3 rounded-lg text-sm">Złóż zamówienie</Link>
      </div>
    </div>
  );
}
