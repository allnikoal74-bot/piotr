"use client";

import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabaseClient";

export default function RegisterPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleRegister(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const supabase = createClient();
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { company_name: companyName } },
    });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    setDone(true);
  }

  if (done) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center">
        <div className="max-w-sm">
          <h1 className="font-display text-xl font-bold mb-2">Sprawdź skrzynkę</h1>
          <p className="text-inkdim text-sm">Wysłaliśmy link potwierdzający na {email}. Kliknij go, żeby dokończyć rejestrację.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <form onSubmit={handleRegister} className="w-full max-w-sm bg-raised border border-line rounded-2xl p-8 flex flex-col gap-4">
        <h1 className="font-display text-xl font-bold">Załóż konto ALLNIKO</h1>
        <input
          placeholder="Nazwa firmy"
          className="bg-bg border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan"
          value={companyName} onChange={(e) => setCompanyName(e.target.value)}
        />
        <input
          required type="email" placeholder="E-mail"
          className="bg-bg border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan"
          value={email} onChange={(e) => setEmail(e.target.value)}
        />
        <input
          required type="password" placeholder="Hasło (min. 6 znaków)" minLength={6}
          className="bg-bg border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-cyan"
          value={password} onChange={(e) => setPassword(e.target.value)}
        />
        {error && <div className="text-amber text-sm">{error}</div>}
        <button type="submit" disabled={loading} className="bg-cyan text-bg font-bold rounded-lg py-3 text-sm disabled:opacity-60">
          {loading ? "Tworzę konto…" : "Zarejestruj się"}
        </button>
        <p className="text-inkdim text-sm text-center">
          Masz już konto? <Link href="/login" className="text-cyan">Zaloguj się</Link>
        </p>
      </form>
    </div>
  );
}
