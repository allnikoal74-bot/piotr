import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { createServerSupabaseClient } from "@/lib/supabaseServer";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export async function POST(request, { params }) {
  const supabase = createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Musisz być zalogowany." }, { status: 401 });

  const { id } = params;

  await supabaseAdmin
    .from("pending_messages")
    .update({ status: "odrzucone" })
    .eq("id", id)
    .eq("owner_id", user.id);

  return NextResponse.json({ status: "odrzucone" });
}
