import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { sendResultEmail } from "@/lib/email";
import { createServerSupabaseClient } from "@/lib/supabaseServer";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * POST /api/pending-messages/[id]/approve
 * To jest jedyne miejsce w całej platformie, które faktycznie wysyła
 * odpowiedź negocjacyjną / z rabatem do klienta — i dzieje się to tylko
 * po kliknięciu przez zalogowanego człowieka w panelu.
 */
export async function POST(request, { params }) {
  const supabase = createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Musisz być zalogowany." }, { status: 401 });

  const { id } = params;

  const { data: msg, error: fetchError } = await supabaseAdmin
    .from("pending_messages")
    .select("*")
    .eq("id", id)
    .eq("owner_id", user.id)
    .single();

  if (fetchError || !msg) {
    return NextResponse.json({ error: "Nie znaleziono wiadomości." }, { status: 404 });
  }

  try {
    await sendResultEmail({
      to: msg.client_email,
      clientName: null,
      agentType: "sales",
      result: msg.draft_reply,
    });
  } catch (err) {
    return NextResponse.json({ error: `Wysyłka nie powiodła się: ${err.message}` }, { status: 502 });
  }

  await supabaseAdmin
    .from("pending_messages")
    .update({ status: "wyslane", approved_at: new Date().toISOString() })
    .eq("id", id);

  return NextResponse.json({ status: "wyslane" });
}
