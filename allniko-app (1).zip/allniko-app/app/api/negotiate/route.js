import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * POST /api/negotiate
 *
 * Klient napisał coś (np. "czy jest możliwy rabat?"). Sales AI przygotowuje
 * gotową odpowiedź z propozycją rabatu W GRANICACH limitu, który Ty ustawiasz
 * (domyślnie max 15%). WAŻNE: ten endpoint NIGDY nie wysyła wiadomości do
 * klienta — tylko zapisuje ją jako szkic do zatwierdzenia w panelu.
 *
 * Body: { owner_id, lead_id, client_email, client_message, max_discount }
 */
export async function POST(request) {
  const body = await request.json();
  const { owner_id, lead_id, client_email, client_message, max_discount } = body;

  if (!client_email || !client_message) {
    return NextResponse.json({ error: "Wymagane: client_email, client_message." }, { status: 400 });
  }

  const discountLimit = Number(max_discount) || 15;

  const systemPrompt = `Jesteś Sales AI platformy ALLNIKO. Klient napisał wiadomość, w której może prosić o rabat lub negocjować warunki. Przygotuj profesjonalną odpowiedź po polsku. Jeśli proponujesz rabat, NIGDY nie przekraczaj ${discountLimit}%. Jeśli klient prosi o więcej niż ${discountLimit}%, zaproponuj maksymalnie ${discountLimit}% i uprzejmie wyjaśnij że to najwięcej na co możesz pójść, ewentualnie zaproponuj inną wartość dodaną zamiast dalszej obniżki ceny. Na końcu, w osobnej linii zaczynającej się od "RABAT:", podaj liczbowo zaproponowany rabat w procentach (np. "RABAT: 10"), albo "RABAT: 0" jeśli nie proponujesz rabatu.`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 700,
      system: systemPrompt,
      messages: [{ role: "user", content: client_message }],
    }),
  });

  if (!response.ok) {
    return NextResponse.json({ error: "Agent nie odpowiedział, spróbuj ponownie." }, { status: 502 });
  }

  const data = await response.json();
  const fullText = (data.content || []).map((b) => (b.type === "text" ? b.text : "")).join("\n");

  const discountMatch = fullText.match(/RABAT:\s*(\d+(\.\d+)?)/i);
  let proposedDiscount = discountMatch ? Number(discountMatch[1]) : 0;
  // Twardy limit egzekwowany też po naszej stronie, nie tylko w prompt — na wypadek,
  // gdyby model coś pomylił.
  if (proposedDiscount > discountLimit) proposedDiscount = discountLimit;

  const draftReply = fullText.replace(/RABAT:\s*\d+(\.\d+)?/i, "").trim();

  const { data: saved, error } = await supabaseAdmin
    .from("pending_messages")
    .insert({
      owner_id: owner_id || null,
      lead_id: lead_id || null,
      client_email,
      client_message,
      draft_reply: draftReply,
      proposed_discount: proposedDiscount,
      max_discount_allowed: discountLimit,
      status: "oczekuje",
    })
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ status: "szkic_gotowy", pending_message: saved });
}
