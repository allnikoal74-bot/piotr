import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { verifyP24Transaction } from "@/lib/przelewy24";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * POST /api/przelewy24/webhook
 *
 * P24 wywołuje ten endpoint automatycznie po próbie płatności.
 * Ustaw ten URL jako urlStatus przy rejestracji transakcji (już to robi
 * /api/przelewy24/register). Musisz go też skonfigurować w panelu P24
 * (Ustawienia -> Twoje dane -> jeśli wymagane potwierdzenie adresu).
 *
 * WAŻNE: sam fakt otrzymania webhooka nic nie znaczy — dopiero jawna
 * weryfikacja (verifyP24Transaction) potwierdza, że pieniądze faktycznie
 * dotarły. Nigdy nie ufaj samej treści webhooka bez weryfikacji.
 */
export async function POST(request) {
  const body = await request.json();
  const { sessionId, amount, orderId } = body;

  try {
    const confirmed = await verifyP24Transaction({ sessionId, amountGrosze: amount, orderId });

    await supabaseAdmin.from("agent_logs").insert({
      agent_type: "platnosci",
      event_type: confirmed ? "success" : "error",
      detail: confirmed
        ? `Płatność Przelewy24 potwierdzona: sesja ${sessionId}, kwota ${amount / 100} zł`
        : `Weryfikacja płatności Przelewy24 nie powiodła się: sesja ${sessionId}`,
    });

    if (confirmed && process.env.RESEND_API_KEY && process.env.OWNER_EMAIL) {
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.RESEND_API_KEY}` },
        body: JSON.stringify({
          from: process.env.RESEND_FROM_EMAIL || "ALLNIKO <no-reply@allniko.pl>",
          to: [process.env.OWNER_EMAIL],
          subject: "💰 Nowa płatność w ALLNIKO (Przelewy24)",
          text: `Sesja: ${sessionId}\nKwota: ${amount / 100} zł\nStatus: opłacone`,
        }),
      }).catch(() => {});
    }

    // P24 oczekuje dokładnie tej odpowiedzi tekstowej, inaczej uzna wywołanie
    // za nieudane i będzie ponawiać próby.
    return new NextResponse(confirmed ? "OK" : "ERROR", { status: confirmed ? 200 : 400 });
  } catch (err) {
    await supabaseAdmin.from("agent_logs").insert({
      agent_type: "platnosci",
      event_type: "error",
      detail: `Błąd weryfikacji webhooka P24: ${err.message}`,
    });
    return new NextResponse("ERROR", { status: 500 });
  }
}
