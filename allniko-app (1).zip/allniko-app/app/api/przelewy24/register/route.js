import { NextResponse } from "next/server";
import { registerP24Transaction } from "@/lib/przelewy24";

/**
 * POST /api/przelewy24/register
 * Body: { plan: 'abonament' | 'serwis_pro' | 'wdrozenie', email }
 *
 * Zwraca URL, na który przekierowujesz klienta — tam wybiera BLIK,
 * przelew tradycyjny albo kartę i płaci.
 */
export async function POST(request) {
  const { plan, email } = await request.json();

  const PLANS_GROSZE = {
    abonament: { amount: 300000, name: "ALLNIKO — AI Abonament (miesięcznie)" },   // 3000,00 zł
    serwis_pro: { amount: 500000, name: "ALLNIKO — AI Serwis Pro (miesięcznie)" }, // 5000,00 zł
    wdrozenie: { amount: 800000, name: "ALLNIKO — Wdrożenie Agentów (jednorazowo)" }, // 8000,00 zł
  };

  const selected = PLANS_GROSZE[plan];
  if (!selected) {
    return NextResponse.json({ error: "Nieznany plan." }, { status: 400 });
  }

  const sessionId = `allniko-${plan}-${Date.now()}`;

  try {
    const { paymentUrl } = await registerP24Transaction({
      sessionId,
      amountGrosze: selected.amount,
      description: selected.name,
      email,
      urlReturn: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard?payment=success`,
      urlStatus: `${process.env.NEXT_PUBLIC_SITE_URL}/api/przelewy24/webhook`,
    });

    return NextResponse.json({ url: paymentUrl, sessionId });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
