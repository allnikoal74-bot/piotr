import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * POST /api/stripe-webhook
 *
 * Stripe wywołuje ten endpoint automatycznie, gdy płatność się powiedzie
 * (albo nie powiedzie, np. odnowienie subskrypcji nie przejdzie).
 * Musisz podać ten URL w Dashboard Stripe -> Developers -> Webhooks:
 * https://twoja-domena.pl/api/stripe-webhook
 */
export async function POST(request) {
  const body = await request.text();
  const signature = request.headers.get("stripe-signature");

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return NextResponse.json({ error: `Nieprawidłowy podpis webhooka: ${err.message}` }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    await supabaseAdmin.from("agent_logs").insert({
      agent_type: "platnosci",
      event_type: "success",
      detail: `Płatność Stripe zakończona sukcesem: ${session.customer_email}, kwota ${session.amount_total / 100} ${session.currency?.toUpperCase()}`,
    });

    // Powiadomienie o zakupie — w odróżnieniu od powiadomień o wizytach,
    // to zawsze warto wysyłać na żywo, bo zdarzeń zakupu jest dużo mniej.
    if (process.env.RESEND_API_KEY && process.env.OWNER_EMAIL) {
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.RESEND_API_KEY}` },
        body: JSON.stringify({
          from: process.env.RESEND_FROM_EMAIL || "ALLNIKO <no-reply@allniko.pl>",
          to: [process.env.OWNER_EMAIL],
          subject: "💰 Nowa płatność w ALLNIKO (Stripe)",
          text: `Klient: ${session.customer_email}\nKwota: ${session.amount_total / 100} ${session.currency?.toUpperCase()}\nStatus: opłacone`,
        }),
      }).catch(() => {});
    }
    // Tu w przyszłości: aktywacja konta klienta, wysyłka maila powitalnego itd.
  }

  if (event.type === "invoice.payment_failed") {
    const invoice = event.data.object;
    await supabaseAdmin.from("agent_logs").insert({
      agent_type: "platnosci",
      event_type: "error",
      detail: `Nieudana płatność Stripe: ${invoice.customer_email || "nieznany klient"}`,
    });
  }

  return NextResponse.json({ received: true });
}
