import { NextResponse } from "next/server";
import { runAgent, AGENT_SYSTEM_PROMPTS } from "@/lib/agents";
import { createServerSupabaseClient } from "@/lib/supabaseServer";

/**
 * POST /api/chat
 * Body: { agent_type, message, provider? }
 *
 * Tylko dla zalogowanych użytkowników panelu — to jest czat "na żywo"
 * (Ty rozmawiasz z agentem), w odróżnieniu od /api/orders, które obsługuje
 * zamówienia przychodzące od Twoich klientów.
 */
export async function POST(request) {
  const supabase = createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Musisz być zalogowany." }, { status: 401 });
  }

  const { agent_type, message, provider } = await request.json();

  if (!agent_type || !AGENT_SYSTEM_PROMPTS[agent_type]) {
    return NextResponse.json({ error: "Nieznany agent." }, { status: 400 });
  }
  if (!message || !message.trim()) {
    return NextResponse.json({ error: "Wiadomość nie może być pusta." }, { status: 400 });
  }

  try {
    const reply = await runAgent(agent_type, message, provider || "anthropic");
    return NextResponse.json({ reply });
  } catch (err) {
    return NextResponse.json({ error: "Agent nie odpowiedział, spróbuj ponownie." }, { status: 502 });
  }
}
