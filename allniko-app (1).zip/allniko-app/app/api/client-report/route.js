import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { createServerSupabaseClient } from "@/lib/supabaseServer";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * POST /api/client-report
 * Body: { client_email }
 *
 * Zbiera całą historię danego klienta (zamówienia, leada, wiadomości
 * negocjacyjne) i prosi agenta AI o napisanie zwięzłej relacji: co się
 * działo, na jakim etapie jest współpraca, co warto zrobić dalej.
 * To NIE jest treść do publikacji bez zmian — to wewnętrzna notatka dla
 * Ciebie, oparta na faktycznych danych z Twojej bazy.
 */
export async function POST(request) {
  const supabase = createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Musisz być zalogowany." }, { status: 401 });
  }

  const { client_email } = await request.json();
  if (!client_email) {
    return NextResponse.json({ error: "Podaj e-mail klienta." }, { status: 400 });
  }

  const [{ data: orders }, { data: leads }, { data: messages }] = await Promise.all([
    supabaseAdmin.from("orders").select("*").eq("client_email", client_email).eq("owner_id", user.id).order("created_at"),
    supabaseAdmin.from("leads").select("*").eq("owner_id", user.id),
    supabaseAdmin.from("pending_messages").select("*").eq("client_email", client_email).eq("owner_id", user.id).order("created_at"),
  ]);

  if ((!orders || orders.length === 0) && (!messages || messages.length === 0)) {
    return NextResponse.json({ error: "Brak zapisanej historii dla tego adresu e-mail." }, { status: 404 });
  }

  const historyText = [
    ...(orders || []).map((o) => `[Zamówienie ${o.created_at}] Agent: ${o.agent_type}. Opis: ${o.payload?.description || ""}. Status: ${o.status}.`),
    ...(messages || []).map((m) => `[Wiadomość ${m.created_at}] Klient napisał: "${m.client_message}". Agent zaproponował: "${m.draft_reply}". Status: ${m.status}.`),
  ].join("\n");

  const systemPrompt = "Jesteś agentem ALLNIKO piszącym wewnętrzną relację z przebiegu współpracy z klientem, na podstawie faktycznych zapisów z systemu. Podsumuj: co się wydarzyło, na jakim etapie jest relacja, jakie są sygnały (zainteresowanie, wahanie, gotowość do zakupu), i zaproponuj jeden konkretny następny krok. Pisz zwięźle, rzeczowo, po polsku, jak notatka dla właściciela firmy. Nie zmyślaj faktów, których nie ma w danych.";

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 700,
      system: systemPrompt,
      messages: [{ role: "user", content: `Historia interakcji z klientem ${client_email}:\n\n${historyText}` }],
    }),
  });

  const data = await res.json();
  const report = (data.content || []).map((b) => (b.type === "text" ? b.text : "")).join("\n");

  return NextResponse.json({ report, eventsCount: (orders?.length || 0) + (messages?.length || 0) });
}
