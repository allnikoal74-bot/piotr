import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * POST /api/voice/status
 *
 * Ustaw w Twilio jako "Call Status Changes" webhook, żeby dostać sygnał
 * gdy rozmowa się zakończy. Wysyła Ci e-mail z podsumowaniem — kto dzwonił
 * i o co pytał, żebyś mógł oddzwonić bez przesłuchiwania nagrania.
 */
export async function POST(request) {
  const formData = await request.formData();
  const callSid = formData.get("CallSid");
  const callStatus = formData.get("CallStatus"); // np. "completed"

  if (callStatus !== "completed") {
    return NextResponse.json({ ok: true });
  }

  const { data: call } = await supabaseAdmin
    .from("phone_calls")
    .select("*")
    .eq("call_sid", callSid)
    .single();

  await supabaseAdmin
    .from("phone_calls")
    .update({ status: "zakonczone", ended_at: new Date().toISOString() })
    .eq("call_sid", callSid);

  if (call && process.env.RESEND_API_KEY && process.env.OWNER_EMAIL) {
    const transcriptText = (call.transcript || [])
      .map((m) => `${m.role === "caller" ? "Dzwoniący" : "Asystent"}: ${m.text}`)
      .join("\n");

    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.RESEND_API_KEY}` },
      body: JSON.stringify({
        from: process.env.RESEND_FROM_EMAIL || "ALLNIKO <no-reply@allniko.pl>",
        to: [process.env.OWNER_EMAIL],
        subject: `📞 Rozmowa telefoniczna: ${call.from_number || "nieznany numer"}`,
        text: `Numer dzwoniącego: ${call.from_number}\n\nPrzebieg rozmowy:\n${transcriptText || "(brak transkrypcji)"}`,
      }),
    }).catch(() => {});
  }

  return NextResponse.json({ ok: true });
}
