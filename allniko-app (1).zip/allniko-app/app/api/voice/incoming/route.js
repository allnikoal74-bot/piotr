import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

function xmlEscape(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/**
 * POST /api/voice/incoming
 *
 * Ustaw ten URL w Twilio: Phone Numbers -> Twój numer -> "A call comes in"
 * -> Webhook -> wklej: https://twoja-domena.pl/api/voice/incoming
 *
 * WAŻNE (wymóg prawny): dzwoniący musi zostać poinformowany, że rozmawia
 * z systemem AI, nie z człowiekiem — stąd zdanie na początku powitania.
 * Nie usuwaj go.
 */
export async function POST(request) {
  const formData = await request.formData();
  const callSid = formData.get("CallSid");
  const fromNumber = formData.get("From");

  await supabaseAdmin.from("phone_calls").insert({
    call_sid: callSid,
    from_number: fromNumber,
    transcript: [],
    status: "w_toku",
  });

  const greeting = "Cześć, dodzwoniłeś się do ALLNIKO. Rozmawiasz z asystentem głosowym opartym na sztucznej inteligencji, nie z człowiekiem. W czym mogę pomóc?";

  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Gather input="speech" language="pl-PL" speechTimeout="auto" action="/api/voice/respond" method="POST">
    <Say language="pl-PL" voice="Polly.Ewa">${xmlEscape(greeting)}</Say>
  </Gather>
  <Say language="pl-PL" voice="Polly.Ewa">Nie usłyszałem odpowiedzi. Do usłyszenia.</Say>
</Response>`;

  return new NextResponse(twiml, { headers: { "Content-Type": "text/xml" } });
}
