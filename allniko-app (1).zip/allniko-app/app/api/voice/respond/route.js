import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

function xmlEscape(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

const SYSTEM_PROMPT = `Jesteś Asystentem Telefonicznym ALLNIKO. Odbierasz połączenia w imieniu właściciela firmy. Rozmawiasz krótko i naturalnie — to rozmowa głosowa, nie czat, więc odpowiadaj w 1-3 zdaniach, bez list i formatowania. Zbieraj: powód telefonu, imię dzwoniącego, numer do oddzwonienia jeśli sprawa wymaga kontaktu z właścicielem. Nie podejmuj decyzji o cenach, rabatach ani zobowiązaniach — zawsze mów, że przekażesz sprawę właścicielowi, który oddzwoni. Jeśli ktoś pyta o coś, czego nie wiesz, powiedz to wprost i zaproponuj przekazanie wiadomości. Odpowiadaj po polsku.`;

/**
 * POST /api/voice/respond
 * Twilio wywołuje to po każdej wypowiedzi dzwoniącego (SpeechResult).
 */
export async function POST(request) {
  const formData = await request.formData();
  const callSid = formData.get("CallSid");
  const speechResult = formData.get("SpeechResult") || "";

  const { data: call } = await supabaseAdmin
    .from("phone_calls")
    .select("*")
    .eq("call_sid", callSid)
    .single();

  const transcript = call?.transcript || [];
  transcript.push({ role: "caller", text: speechResult });

  let reply = "Przepraszam, coś poszło nie tak. Spróbujmy jeszcze raz.";
  try {
    const apiMessages = transcript
      .slice(-10)
      .map((m) => ({ role: m.role === "caller" ? "user" : "assistant", content: m.text }));

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 200,
        system: SYSTEM_PROMPT,
        messages: apiMessages,
      }),
    });
    const data = await res.json();
    reply = (data.content || []).map((b) => (b.type === "text" ? b.text : "")).join(" ") || reply;
  } catch (e) {
    // reply zostaje domyślnym komunikatem o błędzie
  }

  transcript.push({ role: "assistant", text: reply });

  await supabaseAdmin
    .from("phone_calls")
    .update({ transcript })
    .eq("call_sid", callSid);

  // Prosta heurystyka końca rozmowy: dzwoniący pożegnał się.
  const endPhrases = ["dziękuję", "do widzenia", "pa pa", "dzięki, to wszystko"];
  const shouldEnd = endPhrases.some((p) => speechResult.toLowerCase().includes(p));

  const twiml = shouldEnd
    ? `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say language="pl-PL" voice="Polly.Ewa">${xmlEscape(reply)}</Say>
  <Say language="pl-PL" voice="Polly.Ewa">Dziękuję za telefon, do usłyszenia.</Say>
  <Hangup/>
</Response>`
    : `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Gather input="speech" language="pl-PL" speechTimeout="auto" action="/api/voice/respond" method="POST">
    <Say language="pl-PL" voice="Polly.Ewa">${xmlEscape(reply)}</Say>
  </Gather>
  <Say language="pl-PL" voice="Polly.Ewa">Nie usłyszałem odpowiedzi. Dziękuję za telefon.</Say>
</Response>`;

  return new NextResponse(twiml, { headers: { "Content-Type": "text/xml" } });
}
