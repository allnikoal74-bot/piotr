import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { runAgent, generateWebsiteHtml } from "@/lib/agents";
import { sendResultEmail } from "@/lib/email";

// Klient Supabase z uprawnieniami serwisowymi (service role) — może zapisywać
// zamówienia niezależnie od tego, kto je przysyła (formularz, n8n, webhook).
// Klucz service role NIGDY nie trafia do przeglądarki — jest tylko tutaj,
// po stronie serwera.
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * POST /api/orders
 *
 * Ten endpoint to dokładnie to, o co prosiłeś:
 * 1. Klient (albo n8n w jego imieniu) wysyła zamówienie.
 * 2. Zapisujemy je w bazie ze statusem "nowe".
 * 3. Uruchamiamy właściwego agenta AI.
 * 4. Zapisujemy wynik i wysyłamy go e-mailem do klienta.
 * 5. Każdy krok trafia do agent_logs — to zasila panel "Kondycja systemu".
 *
 * Body (JSON):
 * {
 *   "client_email": "klient@firma.pl",
 *   "client_name": "Jan Kowalski",
 *   "agent_type": "grafika",           // sales | wnetrza | nadruki | grafika | prawnik | ksiegowa | serwis
 *   "description": "Potrzebuję logo dla kawiarni specialty coffee...",
 *   "webhook_secret": "..."            // opcjonalnie, jeśli wywołuje n8n — patrz niżej
 * }
 */
export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Nieprawidłowy JSON w treści żądania." }, { status: 400 });
  }

  const { client_email, client_name, agent_type, description, webhook_secret, provider, language } = body;

  // Jeśli wywołanie przychodzi z n8n (nie z zalogowanej sesji), weryfikujemy
  // wspólny sekret, żeby ktokolwiek obcy nie mógł zasypać Cię fałszywymi zamówieniami.
  if (process.env.N8N_WEBHOOK_SECRET && webhook_secret !== process.env.N8N_WEBHOOK_SECRET) {
    return NextResponse.json({ error: "Nieprawidłowy webhook_secret." }, { status: 401 });
  }

  if (!client_email || !agent_type || !description) {
    return NextResponse.json(
      { error: "Wymagane pola: client_email, agent_type, description." },
      { status: 400 }
    );
  }

  // 1. Zapis zamówienia
  const { data: order, error: insertError } = await supabaseAdmin
    .from("orders")
    .insert({
      client_email,
      client_name: client_name || null,
      agent_type,
      payload: { description },
      status: "w_toku",
    })
    .select()
    .single();

  if (insertError) {
    return NextResponse.json({ error: `Błąd zapisu zamówienia: ${insertError.message}` }, { status: 500 });
  }

  await supabaseAdmin.from("agent_logs").insert({
    order_id: order.id,
    agent_type,
    event_type: "start",
    detail: "Zamówienie przyjęte, uruchamiam agenta.",
  });

  // 1b. Automatyczny zapis jako leada w CRM — każde zamówienie to potencjalna
  // dalsza współpraca, więc od razu trafia na listę leadów w panelu Sales AI.
  // owner_id zostaje puste (null), dopóki nie podłączysz przypisywania zamówień
  // do konkretnego konta klienckiego w panelu.
  await supabaseAdmin.from("leads").insert({
    owner_id: order.owner_id || null,
    name: client_name || client_email,
    company: null,
    value: 0,
    stage: "Nowy",
  });

  // 2. Uruchomienie agenta AI
  let result;
  let demoUrl = null;
  try {
    if (agent_type === "web") {
      // Kreator Stron AI: generujemy pełny plik HTML i publikujemy go
      // w Supabase Storage, żeby klient dostał żywy link do podglądu,
      // a nie tylko opis tekstowy.
      const html = await generateWebsiteHtml(description);
      const filePath = `${order.id}.html`;

      const { error: uploadError } = await supabaseAdmin.storage
        .from("demos")
        .upload(filePath, html, { contentType: "text/html", upsert: true });

      if (uploadError) throw new Error(`Błąd publikacji demo strony: ${uploadError.message}`);

      const { data: publicUrlData } = supabaseAdmin.storage.from("demos").getPublicUrl(filePath);
      demoUrl = publicUrlData.publicUrl;
      result = `Twoja strona demo jest gotowa: ${demoUrl}`;
    } else {
      result = await runAgent(agent_type, description, provider || "anthropic", language || "pl");
    }
  } catch (err) {
    await supabaseAdmin.from("agent_logs").insert({
      order_id: order.id,
      agent_type,
      event_type: "error",
      detail: String(err.message || err),
    });
    await supabaseAdmin.from("orders").update({ status: "blad" }).eq("id", order.id);
    return NextResponse.json({ error: "Agent nie zdołał przetworzyć zamówienia." }, { status: 502 });
  }

  await supabaseAdmin
    .from("orders")
    .update({ status: "gotowe", result, demo_url: demoUrl, completed_at: new Date().toISOString() })
    .eq("id", order.id);

  await supabaseAdmin.from("agent_logs").insert({
    order_id: order.id,
    agent_type,
    event_type: "success",
    detail: "Agent zakończył pracę.",
  });

  // 3. Wysyłka wyniku do klienta e-mailem (jeśli skonfigurowano RESEND_API_KEY)
  try {
    await sendResultEmail({ to: client_email, clientName: client_name, agentType: agent_type, result, demoUrl });
    await supabaseAdmin.from("orders").update({ status: "wyslane" }).eq("id", order.id);
    await supabaseAdmin.from("agent_logs").insert({
      order_id: order.id,
      agent_type,
      event_type: "email_sent",
      detail: `Wynik wysłany na ${client_email}.`,
    });
  } catch (err) {
    // Wynik jest gotowy i zapisany, nawet jeśli e-mail się nie wysłał —
    // nic nie ginie, po prostu status zostaje "gotowe" zamiast "wyslane".
    await supabaseAdmin.from("agent_logs").insert({
      order_id: order.id,
      agent_type,
      event_type: "error",
      detail: `Wynik gotowy, ale e-mail nie wysłany: ${err.message}`,
    });
  }

  return NextResponse.json({ status: "ok", order_id: order.id, result });
}
