import { NextResponse } from "next/server";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

/**
 * POST /api/create-checkout-session
 *
 * Płatności międzynarodowe (poza Polską) — Stripe obsługuje karty z całego
 * świata, wiele walut i lokalne metody płatności w danym kraju automatycznie.
 *
 * Body: { plan: 'abonament' | 'serwis_pro' | 'wdrozenie', customer_email }
 *
 * Ceny w USD jako przybliżony odpowiednik cennika w złotówkach:
 * - Abonament: 3000 zł/mies ≈ 750 USD/mies
 * - Serwis Pro: 5000 zł/mies ≈ 1250 USD/mies
 * - Wdrożenie: 8000 zł jednorazowo ≈ 2000 USD
 */
export async function POST(request) {
  const { plan, customer_email } = await request.json();

  const RECURRING_PLANS = {
    abonament: { currency: "usd", unit_amount: 75000, name: "ALLNIKO — AI Abonament (miesięcznie)" },
    serwis_pro: { currency: "usd", unit_amount: 125000, name: "ALLNIKO — AI Serwis Pro (miesięcznie)" },
  };
  const WDROZENIE_PRICE = { currency: "usd", unit_amount: 200000, name: "ALLNIKO — Wdrożenie Agentów (jednorazowo)" };

  try {
    let session;

    if (RECURRING_PLANS[plan]) {
      const selected = RECURRING_PLANS[plan];
      session = await stripe.checkout.sessions.create({
        mode: "subscription",
        payment_method_types: ["card"],
        customer_email: customer_email || undefined,
        line_items: [{
          price_data: { currency: selected.currency, product_data: { name: selected.name }, unit_amount: selected.unit_amount, recurring: { interval: "month" } },
          quantity: 1,
        }],
        success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard?payment=success`,
        cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/order?payment=cancelled`,
      });
    } else if (plan === "wdrozenie") {
      session = await stripe.checkout.sessions.create({
        mode: "payment",
        payment_method_types: ["card"],
        customer_email: customer_email || undefined,
        line_items: [{
          price_data: { currency: WDROZENIE_PRICE.currency, product_data: { name: WDROZENIE_PRICE.name }, unit_amount: WDROZENIE_PRICE.unit_amount },
          quantity: 1,
        }],
        success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard?payment=success`,
        cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/order?payment=cancelled`,
      });
    } else {
      return NextResponse.json({ error: "Nieznany plan." }, { status: 400 });
    }

    return NextResponse.json({ url: session.url });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
