import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * GET /api/health-check
 *
 * Wywoływane automatycznie przez Vercel Cron (patrz vercel.json) co 15 minut,
 * 24 godziny na dobę. To jest "Monitoring AI" ALLNIKO — sprawdza czy kluczowe
 * części systemu żyją i wysyła Ci alert e-mail, jeśli coś nie działa.
 *
 * Zabezpieczone CRON_SECRET, żeby ktoś obcy nie mógł spamować tego endpointu.
 */
export async function GET(request) {
  const authHeader = request.headers.get("authorization");
  if (process.env.CRON_SECRET && authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Brak autoryzacji." }, { status: 401 });
  }

  const results = {};

  // 1. Baza danych — prosty odczyt, sprawdza czy Supabase w ogóle odpowiada.
  try {
    const { error } = await supabaseAdmin.from("agent_logs").select("id").limit(1);
    results.database = error ? `BŁĄD: ${error.message}` : "OK";
  } catch (e) {
    results.database = `BŁĄD: ${e.message}`;
  }

  // 2. Silnik AI — sprawdzamy, czy klucz jest w ogóle ustawiony (pełne
  // zapytanie do Claude kosztowałoby pieniądze przy każdym sprawdzeniu,
  // więc tu tylko weryfikujemy obecność konfiguracji).
  results.anthropic_configured = !!process.env.ANTHROPIC_API_KEY ? "OK" : "BRAK KLUCZA";

  // 3. E-mail (Resend)
  results.email_configured = !!process.env.RESEND_API_KEY ? "OK" : "BRAK KLUCZA (powiadomienia nie wyjdą)";

  // 4. Płatności
  results.stripe_configured = !!process.env.STRIPE_SECRET_KEY ? "OK" : "nieskonfigurowane";
  results.przelewy24_configured = !!process.env.P24_MERCHANT_ID ? "OK" : "nieskonfigurowane";

  const failures = Object.entries(results).filter(([, v]) => v.startsWith("BŁĄD"));
  const overallStatus = failures.length > 0 ? "problem" : "ok";

  await supabaseAdmin.from("agent_logs").insert({
    agent_type: "monitoring",
    event_type: overallStatus === "ok" ? "success" : "error",
    detail: `Kontrola 24/7: ${JSON.stringify(results)}`,
  });

  // Alert e-mailem tylko gdy jest realny problem (nie przy każdym sprawdzeniu,
  // żeby nie zalać Cię e-mailami co 15 minut, gdy wszystko działa).
  if (overallStatus === "problem" && process.env.RESEND_API_KEY && process.env.OWNER_EMAIL) {
    const problemsText = failures.map(([k, v]) => `- ${k}: ${v}`).join("\n");
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.RESEND_API_KEY}` },
      body: JSON.stringify({
        from: process.env.RESEND_FROM_EMAIL || "ALLNIKO <no-reply@allniko.pl>",
        to: [process.env.OWNER_EMAIL],
        subject: "🚨 ALLNIKO — wykryto problem w monitoringu 24/7",
        text: `Automatyczna kontrola wykryła problem:\n\n${problemsText}\n\nSprawdź panel "Kondycja systemu" po zalogowaniu.`,
      }),
    }).catch(() => {});
  }

  return NextResponse.json({ status: overallStatus, results, checkedAt: new Date().toISOString() });
}
