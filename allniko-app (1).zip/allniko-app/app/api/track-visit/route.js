import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * POST /api/track-visit
 * Body: { page, referrer }
 *
 * Wywoływane z landing page przy każdym wejściu. Zapisuje wizytę i —
 * jeśli OWNER_NOTIFY_ON_VISIT=true — wysyła Ci e-mail przy KAŻDEJ wizycie.
 *
 * UWAGA na skalę: to ma sens tylko dopóki masz mało odwiedzin dziennie.
 * Jeśli ruch wzrośnie, zmień OWNER_NOTIFY_ON_VISIT na "false" — wizyty
 * nadal będą zapisywane w site_visits, po prostu bez e-maila za każdym
 * razem (możesz wtedy zrobić dzienne podsumowanie zamiast powiadomień
 * na żywo — daj znać, jeśli chcesz, żebym to dopisał).
 */
export async function POST(request) {
  const { page, referrer } = await request.json();
  const userAgent = request.headers.get("user-agent") || "";

  await supabaseAdmin.from("site_visits").insert({ page, referrer, user_agent: userAgent });

  if (process.env.OWNER_NOTIFY_ON_VISIT === "true" && process.env.RESEND_API_KEY && process.env.OWNER_EMAIL) {
    try {
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.RESEND_API_KEY}` },
        body: JSON.stringify({
          from: process.env.RESEND_FROM_EMAIL || "ALLNIKO <no-reply@allniko.pl>",
          to: [process.env.OWNER_EMAIL],
          subject: "👀 Ktoś wszedł na ALLNIKO",
          text: `Nowa wizyta na stronie.\n\nStrona: ${page}\nSkąd: ${referrer || "bezpośrednio"}\nPrzeglądarka: ${userAgent}`,
        }),
      });
    } catch (e) {
      // Cicho ignorujemy błąd e-maila — sama wizyta i tak została zapisana.
    }
  }

  return NextResponse.json({ ok: true });
}
