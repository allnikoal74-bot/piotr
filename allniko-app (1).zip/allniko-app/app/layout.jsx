import "./globals.css";

export const metadata = {
  title: "ALLNIKO — AI dla Twojego biznesu",
  description: "Panel klienta i agenci AI ALLNIKO",
};

export default function RootLayout({ children }) {
  return (
    <html lang="pl">
      <body className="bg-bg text-ink font-body">{children}</body>
    </html>
  );
}
